package com.sapient.vob;

import lombok.Data;

@Data
public class UserVob {
    private Integer id;
    private String name;
    private String email;
}
