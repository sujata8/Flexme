package com.sapient.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Data
@Entity
@Table(name="reviews")
public class MovieReviewDetails implements Serializable {
    @Id
    @Column(name="movie_id")
    private Integer movieId;

    @Id
    @Column(name="id")
    private Integer reviewId;
}
