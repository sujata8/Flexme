package com.sapient.vob;
import lombok.Data;
@Data
public class UserVob {
    private String email;
    private String password;
}
